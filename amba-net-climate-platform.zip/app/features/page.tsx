import { FeaturesPage } from "@/components/features/features-page"

export default function Features() {
  return <FeaturesPage />
}
