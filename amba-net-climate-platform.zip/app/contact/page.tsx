import { ContactPage } from "@/components/contact/contact-page"

export default function Contact() {
  return <ContactPage />
}
