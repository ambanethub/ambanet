import { ClimateNews } from "@/components/news/climate-news"

export default function NewsPage() {
  return <ClimateNews />
}
