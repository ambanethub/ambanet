import { ResearchRepository } from "@/components/research/research-repository"

export default function ResearchPage() {
  return <ResearchRepository />
}
