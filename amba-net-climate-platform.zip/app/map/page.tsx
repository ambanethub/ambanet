import { ClimateMap } from "@/components/map/climate-map"

export default function MapPage() {
  return <ClimateMap />
}
