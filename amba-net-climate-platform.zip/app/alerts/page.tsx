import { AlertsCenter } from "@/components/alerts/alerts-center"

export default function AlertsPage() {
  return <AlertsCenter />
}
